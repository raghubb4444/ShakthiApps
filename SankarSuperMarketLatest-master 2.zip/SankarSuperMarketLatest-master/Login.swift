//
//  Login.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/23/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import Foundation

class Login
{
 //   var ID: String
 //   var Name: String
    var EmailID : String
    var Password : String
    
    init?(EmailID : String, Password : String)
    {
  //      self.ID = ID
   //     self.Name = Name
        self.EmailID = EmailID
        self.Password = Password
    }
    
    
}