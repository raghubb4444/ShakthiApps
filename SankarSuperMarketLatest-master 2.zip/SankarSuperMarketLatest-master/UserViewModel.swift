//
//  UserViewModel.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/24/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//


import Foundation

class UserViewModel
{
       var ID: String
       var Name: String
    
    init?(ID : String, Name : String)
    {
        //      self.ID = ID
        //     self.Name = Name
        self.ID = ID
        self.Name = Name
    }
    
    
}
