//
//  RecurringTableViewCell.swift
//  SankarSuperMarket
//
//  Created by Admin on 9/20/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit

class RecurringTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    

    
}
