//
//  HomeCell.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/7/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit

class HomeCell: UITableViewCell {
    
//
//    @IBOutlet weak var categorylbl: UILabel!
//    
//    @IBOutlet weak var categoryimg: UIImageView!
//
    
  

}
