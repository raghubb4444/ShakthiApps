//
//  NoticeCell.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/8/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit

class NoticeCell: UITableViewCell {
    
    @IBOutlet weak var noticeimg: UIImageView!
    
    @IBOutlet weak var noticelbl: UILabel!
    
    

}
