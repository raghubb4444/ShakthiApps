//
//  notice.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/8/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit
class Notice {

    var noticePhoto:UIImage?
    // MARK: Initialization
    
    init?(noticePhoto: UIImage) {
        // Initialize stored properties.

        self.noticePhoto = noticePhoto
        
        // Initialization should fail if there is no name or if the rating is negative.
        
    }
    
}
