
//
//  WishViewModel.swift
//  SankarSuperMarket
//
//  Created by Admin on 7/14/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import Foundation
class WishViewModel {
    
    var UserID: String
    var Name: String
    init?(UserID: String, Name: String){
        self.UserID = UserID
        self.Name = Name
        
    }
    
}