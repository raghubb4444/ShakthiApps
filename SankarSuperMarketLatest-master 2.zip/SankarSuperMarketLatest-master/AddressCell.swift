//
//  AddressCell.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/14/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit

class AddressCell: UITableViewCell {
    

  

}
